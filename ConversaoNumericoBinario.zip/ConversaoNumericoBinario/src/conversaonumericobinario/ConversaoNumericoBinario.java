package conversaonumericobinario;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Scanner;

public class ConversaoNumericoBinario {

    private List<Integer> leitura = new ArrayList<>();
    private List<String> resultado = new ArrayList<>();
    public static void main(String[] args) {
        new ConversaoNumericoBinario().executar();
    }

    private void executar() {
        Scanner scanner = new Scanner(System.in);
        String valor;
        do{
            valor = scanner.nextLine();
            if(!valor.isEmpty()){
                leitura.add(Integer.parseInt(valor));
            }
        }while(!valor.isEmpty());
        
        Collections.sort(leitura);
        
        /*
            Faixas definidas:
            < 0
            0 a 5
            5 a 10
            10 a 15
            > 15
        */
        String cabecalho = "<0      0 a 5    5 a 10    10 a 15  >15";
        resultado.add(cabecalho);
        for(Integer numero : leitura){
            String linha = "";
            if(numero < 0){
                linha  = "true    false    false    false    false";
            }else if(numero >= 0 && numero < 5){
                linha  = "false   true     false    false    false";
            }else if(numero >= 5 && numero < 10){
                linha  = "false   false    true     false    false";
            }else if(numero >= 10 && numero < 15){
                linha  = "false   false    false    true     false";
            }else{
                linha  = "false   false    false    false    true";
            }
            resultado.add(linha);
        }
        System.out.println(leitura);
        for(String linha : resultado){
            System.out.println(linha);
        }
    }
    
}
