package redeneural;

public class Main {

    double bias = -1;
    double wBias = 0.5;
    double eta = 0.3;
    double erroMaximoAceitavel = 0;
    int maxEpocas = 1000;
    double entradas[][] = {{0, 0}, {0, 1}, {1, 0}, {1, 1}};
    double yDs[] = {0, 0, 0, 1};
    double ws[] = {0.2, -0.3};

    public static void main(String[] args) {
        Main obj = new Main();
        obj.executar();
    }

    private void executar() {
        treinar();
    }

    private void treinar() {

        double erroEpoca = 1;
        int epoca = 0;
        //Treinamento
        while (erroEpoca > erroMaximoAceitavel && epoca < maxEpocas) {
            erroEpoca = 0;
            System.out.println("Época: "+ (epoca+1));
            //Epoca
            for (int i = 0; i < entradas.length; i++) {
                //Iteração
                //Calcular o valor de V
                double v1 = (wBias * bias) + (ws[0] * entradas[i][0]) + (ws[1] * entradas[i][1]);
                System.out.println("VVVVVVVVVVVV0"+v1);
                double v = (ws[0] * entradas[i][0]) + (ws[1] * entradas[i][1]) + (wBias * bias);
                System.out.println("VVVVVVVVVVVV1"+v);
                //Calcular o valor de Y
                double y = 0;
                if (v >= 0) {
                    y = 1;
                }

                //Calcular o valor do ERRO
                double erroIteracao = yDs[i] - y;

                //Ajustar os pesos
                wBias = wBias + (bias * erroIteracao * eta);
                ws[0] = ws[0] + (entradas[i][0] * erroIteracao * eta);
                ws[1] = ws[1] + (entradas[i][1] * erroIteracao * eta);

                //Incrementar o ERRO da epoca
                if (erroIteracao != 0) {
                    erroEpoca++;
                }
                System.out.println(entradas[i][0] + " | " + entradas[i][1] + " | " + yDs[i] + " -> " + y);
            }
            epoca++;
        }
        System.out.println("Numero de Epocas: " + epoca);
    }

}
