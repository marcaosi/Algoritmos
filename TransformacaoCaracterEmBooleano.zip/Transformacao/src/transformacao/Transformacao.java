package transformacao;

import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Set;

public class Transformacao {
    
    private List<String> entradaList = new ArrayList<>();
    private Set<String> produtoSet = new LinkedHashSet<>();
    
    private void executar() {
        //Lendo os dados
        Scanner scanner = new Scanner(System.in);
        
        String entrada;
        do{
            entrada = scanner.nextLine().trim().toLowerCase();
            if(!entrada.isEmpty()){
                entradaList.add(entrada);
            }
        }while(!entrada.isEmpty());
        //Unificando os dados
        for(String aux : entradaList){
            String[] produtos = aux.split(",");
            for(String produto : produtos){
                produtoSet.add(produto.trim());
            }
        }
        //imprimindo os dados
        String cabecalho = "";
        for(String aux : produtoSet){
            cabecalho += ","+aux;
        }
        
        cabecalho = cabecalho.substring(1);
        System.out.println(cabecalho);
        
        //transformando os dados
        for(String auxEntrada : entradaList){
            String linha = "";
            String[] produtos = auxEntrada.split(",");
            for(String auxProdutos : produtoSet){
                boolean valor = false;
                for(String produto : produtos){
                    if(auxProdutos.equals(produto)){
                        valor = true;
                        break;
                    }
                }
                linha += ","+valor;
            }
            System.out.println(linha.substring(1));
        }
    }
    
    public static void main(String[] args) {
        Transformacao obj = new Transformacao();
        obj.executar();
    }

    
}
